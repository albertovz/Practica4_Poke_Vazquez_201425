import React from "react";

const Footer = () => (
    <footer>
        <div>
            Alberto Vázquez Miranda - 201425
        </div>
        <div>
            Universidad Politénica de Chiapas
        </div>
    </footer>
);

export default Footer;
